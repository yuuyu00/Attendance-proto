export const SIGN_IN = 'SIGN_IN';
export const SIGN_OUT = 'SIGN_OUT';
export const CREATE_KINTAI = 'CREATE_KINTAI';
export const FETCH_KINTAIS = 'FETCH_KINTAIS';
export const FETCH_KINTAI = 'FETCH_KINTAI';
export const DELETE_KINTAI = 'DELETE_KINTAI';
export const EDIT_KINTAI = 'EDIT_KINTAI';
