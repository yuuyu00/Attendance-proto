import React, { useState, useEffect } from 'react';

export default () => {
  return <div>KintaiForm</div>;
};
